package fr.antoineok.antistealapi;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class AntiStealAPI
{
    private String url;
    private Gson gson = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();
    ClientValue clientValue;

    public ClientValue getClientValue()
    {
        return this.clientValue;
    }

    public void ExceptionThrower() throws LauncherNotPaidException
    {
        throw new LauncherNotPaidException();
    }

    public AntiStealAPI(String url, Domain domain, String clientName) throws Exception
    {
        if(url == null)
        {
            throw new NullPointerException("The url cannot be null, verify the instance");
        }
        if(domain == null)
        {
            throw new NullPointerException("The domain cannot be null, check the enum (Domain.HTTP or Domain.HTTPS)");
        }
        if(url.isEmpty())
        {
            throw new RuntimeException("The url cannot be empty, verify the url");
        }
        if(url.startsWith("https://"))
        {
            url.replace("https://", "http://");
        }
        if(url.startsWith("http://"))
        {
            url.replace("http://", "");
        }
        this.url = domain.getDomain() + url;
        String json = this.isPaid(clientName);
        this.clientValue = this.gson.fromJson(json, ClientValue.class);
    }

    private String isPaid(String clientName) throws Exception
    {
        String url = this.url + "?clientName=" + clientName;
        DefaultHttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet(url);
        request.addHeader("User-Agent", "Mozilla/5.0");
        HttpResponse response = client.execute(request);
        BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
        StringBuffer result = new StringBuffer();
        String line = "";
        while((line = rd.readLine()) != null)
        {
            result.append(line);
        }
        return result.toString();
    }
}
