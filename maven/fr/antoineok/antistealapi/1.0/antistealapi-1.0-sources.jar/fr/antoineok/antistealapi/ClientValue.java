package fr.antoineok.antistealapi;

public class ClientValue
{
    private String clientName;
    private int hasPaid;

    public ClientValue(String clientName, int hasPaid) {
        this.clientName = clientName;
        this.hasPaid = hasPaid;
    }

    public String getClientName() {
        return this.clientName;
    }

    public boolean hasPaid() {
        return this.hasPaid == 1;
    }
}
