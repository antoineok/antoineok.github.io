package fr.antoineok.antistealapi;

public class LauncherNotPaidException extends Exception
{

}
